var check=false
var slide = document.getElementById('slider');
var line = document.getElementById('txt');
var bdy = document.getElementById('bdyy');
slide.addEventListener('click', function(){
    if(check==false){
        slide.style.marginLeft="50px";
        line.style.color="white";
        bdy.style.backgroundColor="black"
        check=true;
    }else{
        slide.style.marginLeft="0px";
        line.style.color="black";
        bdy.style.backgroundColor="white"
        check=false;
    }
    
});
    