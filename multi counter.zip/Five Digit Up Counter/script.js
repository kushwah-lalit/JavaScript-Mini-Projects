var btn=document.getElementById("mybtn");
btn.addEventListener("click", function() {
  let num=parseInt(document.getElementById("txt").value);
    if (isNaN(num)) {
        alert("Please enter a number");
        clearInterval(countInterval);   
        return;
    }
   document.getElementById("txt").value="";
    var c = document.querySelectorAll("#block .crnt");
    var n = document.querySelectorAll("#block .nxt");
   for(let i of c){
       i.innerText="0";
   }
    for(let i of n){
       i.innerText="1";
   }
  let count=0;
    // if(count>0){
    // c.innerText="0";
    // n.innerText="1";
    // alert("Please enter a number");
    // clearInterval(countInterval);   
    // return;
    // }
 var interval=setInterval(function(){
      if(count==num){
        clearInterval(interval);
        alert("Counter has stopped");
       for(let i of c){
       i.innerText="0";
   }
    for(let i of n){
       i.innerText="1";
   }
        return;
      }
      movecount(c,n,4);
      count++;
  },1000);
    
});
function movecount(c,n,indx){
    var N=n[indx];
    var C=c[indx];
    if(C.innerText==9){
        movecount(c,n,indx-1);
    }
    N.classList.add("animate");
    setTimeout(function (){
        C.innerText = N.innerText;
        N.classList.remove("animate");
        N.innerText = parseInt(N.innerText) + 1;
        if(N.innerText > 9) {
            N.innerText = 0;
        }
    }, 500);
}