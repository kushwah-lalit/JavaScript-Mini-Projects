var ball = document.getElementById('ball');
var rod1 = document.getElementById('rod1');
var rod2 = document.getElementById('rod2');
var game=false;
var speedX=2;
var speedY=2;
var max=0;
var score=0;
const storeName = "PPName";
const storeScore = "PPMaxScore";
(function () {
    var rod = localStorage.getItem(storeName);
    maxScore = localStorage.getItem(storeScore);

    if (rod === "null" || max === "null") {
        alert("This is the first time you are playing this game. LET'S START");
        max = 0;
        rod = "Rod1"
    } else {
        alert(rod + " has maximum score of " + max * 100);
    }
    rod1.style.left = (window.innerWidth - rod1.offsetWidth) / 2 + 'px';
    rod2.style.left = (window.innerWidth - rod2.offsetWidth) / 2 + 'px';
    ball.style.left = (window.innerWidth - ball.offsetWidth) / 2 + 'px';


    // Lossing player gets the ball
    if (rod === "Rod2") {
        ball.style.top = (rod1.offsetTop + rod1.offsetHeight) + 'px';
        speedY = 2;
    } else if (rod === "Rod1") {
        ball.style.top = (rod2.offsetTop - rod2.offsetHeight) + 'px';
        speedY = -2;
    }

    score = 0;
    game= false;

   
})();
window.addEventListener('keypress', function (){
    let rodMov=rod1.getBoundingClientRect();
    if(event.key=='A'||event.key=='a'){
        if(rodMov.x>0){
            rod1.style.left=rodMov.x-20+'px';
            rod2.style.left=rod1.style.left;
        }
    }else if(event.key=='D'||event.key=='d'){
        if((rodMov.x+rodMov.width)<window.innerWidth){
            rod1.style.left=rodMov.x+20+'px';
            rod2.style.left=rod1.style.left;
        }  
    }
    if(event.key=="Enter"){
        if(!game){
            game=true;
         
            let Rod1=rod1.getBoundingClientRect();
            let Rod2=rod2.getBoundingClientRect();
            let Ball=ball.getBoundingClientRect();
            let interval=setInterval(function(){
                Ball.x+=speedX;
                Ball.y+=speedY;
                ball.style.left=Ball.x+'px';
                ball.style.top=Ball.y+'px';
                if(Ball.x<0||(Ball.x+Ball.width)>window.innerWidth){
                    speedX= -speedX;
                }
                //upr y=0 hai
                // for y use evertime rod offeset...because keeps on updationg
                if(Ball.y<=rod1.offsetHeight){
                    speedY= -speedY;
                    score++;
                    if((Ball.x+Ball.width)<Rod1.x||Ball.x>(Rod1.x+rod1.offsetWidth)){
                        if(score>max){
                        max=score;
                        localStorage.setItem(storeName,"Rod2");
                        localStorage.setItem(storeScore, max);
                        }
                        clearInterval(interval);
                        rod1.style.left = (window.innerWidth - rod1.offsetWidth) / 2 + 'px';
                        rod2.style.left = (window.innerWidth - rod2.offsetWidth) / 2 + 'px';
                        ball.style.left = (window.innerWidth - ball.offsetWidth) / 2 + 'px';


                        // Lossing player gets the ball
                        ball.style.top = (rod1.offsetTop + rod1.offsetHeight) + 'px';
                        speedY = 2;
                   
                        

                        score = 0;
                        game= false;
                        alert("Rod2 wins with a score of " + (score * 100) + ". Max score is: " + (max * 100));
                        
                    }
                }else if((Ball.y+Ball.width)>=(window.innerHeight-rod2.offsetHeight)){
                    speedY= -speedY;
                    score++;
                    if(Ball.y<=rod1.offsetHeight){
                    speedY= -speedY;
                    score++;
                    }
                    if((Ball.x+Ball.width)<Rod1.x||Ball.x>(Rod1.x+rod1.offsetWidth)){
                        if(score>max){
                        max=score;
                        localStorage.setItem(storeName,"Rod1");
                        localStorage.setItem(storeScore, max);
                        }
                        clearInterval(interval);
                        rod1.style.left = (window.innerWidth - rod1.offsetWidth) / 2 + 'px';
                        rod2.style.left = (window.innerWidth - rod2.offsetWidth) / 2 + 'px';
                        ball.style.left = (window.innerWidth - ball.offsetWidth) / 2 + 'px';


                        // Lossing player gets the ball
                        ball.style.top = (rod2.offsetTop - rod2.offsetHeight) + 'px';
                        speedY = -2;
                   
                        

                        score = 0;
                        game= false;
                        alert("Rod1 wins with a score of " + (score * 100) + ". Max score is: " + (max * 100));
                        
                    }
                }
            }, 10);
            
        }
    }
});
