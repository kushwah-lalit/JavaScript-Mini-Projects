var scrolledBar=document.querySelector("#mtr span");
function getDocHeight() {
    var D = document;
    return Math.max(
        D.body.scrollHeight, D.body.offsetHeight, D.body.clientHeight
    );
}
window.onresize = function (e) {
    docHeight = getDocHeight();
    windowHeight = window.innerHeight;
};
console.log(scrolledBar.innerText);
window.addEventListener('scroll', function(){
var windowHeight = window.innerHeight;
    var docHeight = getDocHeight();
    var scrolled = Math.floor((window.scrollY/(docHeight-windowHeight))*100);
    scrolledBar.innerText = scrolled;
});