var colorcount=0;
var shapecount=0;
var cir = document.getElementById('main');
var shp = document.getElementById('shape');
var colorbtn = document.getElementById('color');
var shapebtn = document.getElementById('Cngshape');
function colorF(){
    if(colorcount==0){
        cir.style.backgroundColor="cyan";
        colorcount++;
    }else if(colorcount==1){
        cir.style.backgroundColor="red";
        colorcount++;
    }else if(colorcount==2){
        cir.style.backgroundColor="blue";
        colorcount++;
    }
    else if(colorcount==3){
        cir.style.backgroundColor="purple";
        colorcount=0;
    }
}
function shape(){
    if(shapecount==0){
        shp.style.borderRadius="50%";
        shapecount++;
    }else if(shapecount==1){
        shp.style.borderRadius="0%";
        shp.style.height="50px";
        shp.style.top="75px"
        shapecount++;
    }else if(shapecount==2){
        shp.style.borderRadius="0%";
        shp.style.height="100px";
         shp.style.top="50px";
        shapecount=0;
    }
}
colorbtn.addEventListener('click',colorF);
shapebtn.addEventListener('click',shape);
    