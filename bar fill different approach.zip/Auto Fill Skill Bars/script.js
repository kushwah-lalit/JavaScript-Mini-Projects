
var observer = new IntersectionObserver(function(entries) {
	// isIntersecting is true when element and viewport are overlapping
	// isIntersecting is false when element and viewport don't overlap
	if(entries[0].isIntersecting === true){
        var divFillers=document.querySelectorAll(".skill-progress > div");
        for(let i of divFillers){
            i.style.width=0+'%';
            // let mark=i.getAttribute('data-value');
            let count=0;
            let interval=setInterval(function(){
                let mark=i.getAttribute('data-value');
                if(count>=mark){
                    clearInterval(interval);
                    return;
                }
                count++;
                i.style.width=count+'%';
               
            },1);
        }
    }
		
}, { threshold: [0] });

observer.observe(document.querySelector("#skills"));


// window.addEventListener("scroll", function() {
// 	var element =document.getElementById('skills');
// 	var position = element.getBoundingClientRect();
// 	if(position.top<= window.innerHeight) {
//         var divFillers=document.querySelectorAll(".skill-progress > div");
//         for(let i of divFillers){
//             // i.style.width=0+'%';
//             // let mark=i.getAttribute('data-value');
//             let count=0;
//             var interval=setInterval(function(){
//                 let mark=i.getAttribute('data-value');
//                 if(count==mark){
//                     clearInterval(interval);
//                     count=0;
//                     return;
//                 }
//                 count++;
//                 i.style.width=count+'%';
               
//             },20);
//         }
//     }else{
//         var divFillers=document.querySelectorAll(".skill-progress > div");
//         for(let i of divFillers){
//             i.style.width=0+'%';
//         }
//     }
// });
