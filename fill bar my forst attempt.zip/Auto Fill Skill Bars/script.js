var check=false;
window.addEventListener("scroll", function() {
	var element =document.getElementById('skills');
	var position = element.getBoundingClientRect();

	// checking whether fully visible
	if(check==false&&position.top<= window.innerHeight) {
        check=true;
        var divFillers=document.querySelectorAll(".skill-progress > div");
        for(let i of divFillers){
            i.style.width=0+'%';
            // let mark=i.getAttribute('data-value');
            let count=0;
            let interval=setInterval(function(){
                let mark=i.getAttribute('data-value');
                if(count>=mark){
                    clearInterval(interval);
                    count=0;
                    return;
                }
                count++;
                i.style.width=count+'%';
               
            },5);
        }
       
    }
});
