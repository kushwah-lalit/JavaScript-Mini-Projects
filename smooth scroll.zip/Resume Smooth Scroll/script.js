var linktags=document.querySelectorAll('.nav-menu a');
for(var i=0;i<linktags.length;i++){
    linktags[i].addEventListener('click',function(event){
        event.preventDefault();
        var sections=this.textContent.trim().toLowerCase();
        var sectionreach=document.getElementById(sections);
        var coordinate=sectionreach.getBoundingClientRect();
        var current=0;
        var scrollInterval=setInterval(function(){
          if(current>=coordinate.y){
              clearInterval(scrollInterval);
              return;
          } 
           current+=50;
            window.scrollBy(0,50);
        },50);
        
    });
}
