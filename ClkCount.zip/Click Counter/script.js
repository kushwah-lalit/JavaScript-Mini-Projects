var box= document.getElementById('box');
var txt=document.getElementById('count');
var count=0;
function counter(){
    count++;
    txt.innerText =" "+ count;
}
box.addEventListener('click', counter);