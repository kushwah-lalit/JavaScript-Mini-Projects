var btn=document.getElementById("mybtn");
btn.addEventListener("click", function() {
  let num=parseInt(document.getElementById("txt").value);
    if (isNaN(num)) {
        alert("Please enter a number");
        clearInterval(countInterval);   
        return;
    }
  document.getElementById("txt").value="";
  var c=document.querySelector(".crnt");
  var n=document.querySelector(".nxt");
  let count=0;
  c.innerText="0";
  n.innerText="1";
    if(count>0){
    c.innerText="0";
    n.innerText="1";
    alert("Please enter a number");
    clearInterval(countInterval);   
    return;
    }
 var interval=setInterval(function(){
      if(count==num){
        clearInterval(interval);
        alert("Counter has stopped");
         c.innerText="0";
         n.innerText="1";
        return;
      }
      movecount(c,n);
      count++;
  },1000);
    
});
function movecount(c,n){
    n.classList.add("animate");
    setTimeout(function (){
        c.innerText = n.innerText;
        n.classList.remove("animate");
        n.innerText = parseInt(n.innerText) + 1;
    }, 500);
}