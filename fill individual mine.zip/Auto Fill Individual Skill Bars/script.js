var len=0
var arr;
for(let i=0;i<len;i++){
        arr[i]=false;
}
window.addEventListener("scroll", function() {
	var elements =document.querySelectorAll(".skill-progress >div");
    len=elements.length;
    let e=0;
    for(let ele of elements){
        let position=ele.getBoundingClientRect();
        if(arr[e]==false&&position.top<= window.innerHeight) {
        arr[e]=true;
            ele.style.width=0+'%';
            // let mark=i.getAttribute('data-value');
            let count=0;
            let interval=setInterval(function(){
                let mark=ele.getAttribute('data-value');
                if(count>=mark){
                    clearInterval(interval);
                    count=0;
                    return;
                }
                count++;
                ele.style.width=count+'%';
               
            },5);

     }else if(position.top>window.innerHeight){
        arr[e]=false;
        ele.style.width=0+'%';
        
    }
      e++;  
    }	
});
