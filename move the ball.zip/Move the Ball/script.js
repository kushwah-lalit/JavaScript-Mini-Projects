var ball=document.getElementById("ball");
ball.style.top = ball.offsetTop + "px";
ball.style.left = ball.offsetLeft + "px";
var ballHeight = ball.offsetHeight;
var ballWidth = ball.offsetWidth;
document.addEventListener("keypress",function(event){
    var top = parseInt(ball.style.top);
    var left = parseInt(ball.style.left);
    if (event.key === "W" ||event.key === "w") {
        if (top > 5) {
            top-=5
            ball.style.top = top+"px";
        }
    }else if (event.key=== "A" || event.key=== "a") {
        if (left > 5) {
            left-=5;
            ball.style.left = left+"px";
        }
    }else if (event.key === "S"|| event.key=== "s") {
        if (top < (window.innerHeight - ballHeight) - 5) {
            top+=5;
            ball.style.top = top+"px";
        }
    } else if (event.key === "D" || event.key === "d") {
        if (left < (window.innerWidth - ballWidth) - 5) {
            left+=5;
            ball.style.left = left+"px";
        }
    }
});


///if we use keyCode then need to ascii value
// if we use key then we use char
/// if we use code then we use keyA like